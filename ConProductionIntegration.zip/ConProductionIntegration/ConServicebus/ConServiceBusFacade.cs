﻿using Microsoft.ServiceBus.Messaging;
using System.IO;
namespace ConServiceBus
{
    public class ServiceBusFacade
    {
        public static Stream GetBodyStream(BrokeredMessage _message)
        {
            return _message.GetBody<Stream>();
        }
    }
}