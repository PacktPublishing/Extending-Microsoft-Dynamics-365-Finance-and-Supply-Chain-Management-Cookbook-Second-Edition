﻿// This structure follows the Open Weather schema as of August 2019

namespace Contoso.WeatherService
{
    public class OpenWeatherMap
    {
        public OpenWeatherMapCoord coord { get; set; }
        public OpenWeatherMapMain main { get; set; }
        public string name { get; set; }
        public string country { get; set; }
    }
    public class OpenWeatherMapCoord
    {
        public double lon { get; set; }
        public double lat { get; set; }
    }
    public class OpenWeatherMapMain
    {
        public double temp { get; set; }
        public int pressure { get; set; }
        public int humidity { get; set; }
        public double temp_min { get; set; }
        public double temp_max { get; set; }
    }

}
