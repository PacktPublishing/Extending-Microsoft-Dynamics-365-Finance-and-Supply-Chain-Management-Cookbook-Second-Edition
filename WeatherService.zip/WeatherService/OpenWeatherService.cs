﻿using Newtonsoft.Json;
using System.Net;
using System.IO;

namespace Contoso.WeatherService
{
    public class OpenWeatherService
    {
        const string OpenWeatherMapAppKey = "746e1aa9df287a671255cb89eb183021";
        public OpenWeatherMap GetWeatherForLocation(double _lon, double _lat)
        {
            string address = $"http://api.openweathermap.org/data/2.5/weather?lat={_lat}&lon={_lon}&appid={OpenWeatherMapAppKey}";
            HttpWebRequest request = this.CreateRequest(address);
            string response = this.ReadJsonResponse(request);
            return JsonConvert.DeserializeObject<OpenWeatherMap>(response);
        }
        private HttpWebRequest CreateRequest(string _address)
        {
            HttpWebRequest webRequest;
            webRequest = (HttpWebRequest)HttpWebRequest.Create(_address);
            webRequest.Method = "POST";
            // the request will be empty. 
            webRequest.ContentLength = 0;
            return webRequest;
        }
        private string ReadJsonResponse(HttpWebRequest _request)
        {
            string jsonString;

            using (HttpWebResponse webResponse = (HttpWebResponse)_request.GetResponse())
            {
                using (Stream stream = webResponse.GetResponseStream())
                {
                    using (StreamReader reader = new StreamReader(stream))
                    {
                        jsonString = reader.ReadToEnd();
                    }
                }
            }
            return jsonString;
        }
    }
}
